# Selenium_Automation
Automating Testing for Incorta Applications, as well as generating scripts to fulfill manual commands
