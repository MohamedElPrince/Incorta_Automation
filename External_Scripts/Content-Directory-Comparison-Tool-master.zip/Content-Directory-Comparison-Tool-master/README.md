# Content-Directory-Comparison-Tool

Supported Operating Systems: Windows, Mac OS, Linux

Purpose: 
The purpose of the tool is to give the developer or user a method to observe and review changes in tenants, dashboards, schemas, and schema tables prior to applying the changes to a production system

May also be used to compare any two files in XML format.

*For instructions on how to install and run the tool read the CONFIG file. 
