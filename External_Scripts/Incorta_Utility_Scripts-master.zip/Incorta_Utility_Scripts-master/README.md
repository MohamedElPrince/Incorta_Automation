# Incorta_Utility_Scripts
Scripts include adding to git, exporting tenants, etc.
